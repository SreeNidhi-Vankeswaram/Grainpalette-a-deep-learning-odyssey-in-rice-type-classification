# Face Detection Models

This directory will contain the face-api.js models that will be loaded at runtime.

The models will be automatically downloaded from the CDN when the application runs for the first time.

Required models:
- tiny_face_detector_model
- face_landmark_68_model
- face_recognition_model
- face_expression_model

These models are loaded from the face-api.js CDN and cached in the browser.