// Type definition for emotion result
export interface EmotionResult {
  timestamp: string;
  primaryEmotion: string;
  primaryConfidence: number;
  secondaryEmotion: string;
  secondaryConfidence: number;
  allEmotions: {[key: string]: number};
}

// Local storage key
const STORAGE_KEY = 'emotion_history';

/**
 * Save emotion detection result to local storage
 * @param {EmotionResult} result - The emotion detection result
 */
export const saveEmotionResult = (result: EmotionResult): void => {
  try {
    // Get existing history
    const history = getEmotionHistory();
    
    // Add new result
    history.push(result);
    
    // Limit history to last 100 entries
    const limitedHistory = history.slice(-100);
    
    // Save to local storage
    localStorage.setItem(STORAGE_KEY, JSON.stringify(limitedHistory));
  } catch (error) {
    console.error('Error saving emotion result:', error);
  }
};

/**
 * Get emotion detection history from local storage
 * @returns {EmotionResult[]} - Array of emotion detection results
 */
export const getEmotionHistory = (): EmotionResult[] => {
  try {
    const historyJson = localStorage.getItem(STORAGE_KEY);
    
    if (!historyJson) {
      return [];
    }
    
    return JSON.parse(historyJson);
  } catch (error) {
    console.error('Error retrieving emotion history:', error);
    return [];
  }
};

/**
 * Clear all emotion detection history
 */
export const clearEmotionHistory = (): void => {
  try {
    localStorage.removeItem(STORAGE_KEY);
  } catch (error) {
    console.error('Error clearing emotion history:', error);
  }
};

/**
 * Get statistics from emotion history
 * @returns {Object} - Statistics object
 */
export const getEmotionStats = () => {
  const history = getEmotionHistory();
  
  if (history.length === 0) {
    return null;
  }
  
  // Count occurrences of each primary emotion
  const emotionCounts: {[key: string]: number} = {};
  
  history.forEach(entry => {
    emotionCounts[entry.primaryEmotion] = (emotionCounts[entry.primaryEmotion] || 0) + 1;
  });
  
  // Calculate percentages
  const totalEntries = history.length;
  const emotionPercentages = Object.entries(emotionCounts).map(([emotion, count]) => ({
    emotion,
    count,
    percentage: (count / totalEntries) * 100
  }));
  
  // Sort by percentage (descending)
  emotionPercentages.sort((a, b) => b.percentage - a.percentage);
  
  // Get most recent entry
  const latestEntry = history[history.length - 1];
  
  return {
    totalEntries,
    emotionCounts,
    emotionPercentages,
    latestEntry,
    uniqueEmotions: Object.keys(emotionCounts).length
  };
};