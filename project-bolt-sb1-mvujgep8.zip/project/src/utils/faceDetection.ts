import * as faceapi from 'face-api.js';
import * as tf from '@tensorflow/tfjs';
import { saveEmotionResult } from './emotionStorage';

// Flag to track if models are loaded
let modelsLoaded = false;

/**
 * Load all required face-api.js models
 */
export const loadModels = async () => {
  if (modelsLoaded) return;
  
  try {
    // Use the CDN URL instead of local path since models aren't available locally
    const MODEL_URL = 'https://justadudewhohacks.github.io/face-api.js/models';
    
    // Load models
    await Promise.all([
      faceapi.nets.tinyFaceDetector.loadFromUri(MODEL_URL),
      faceapi.nets.faceLandmark68Net.loadFromUri(MODEL_URL),
      faceapi.nets.faceRecognitionNet.loadFromUri(MODEL_URL),
      faceapi.nets.faceExpressionNet.loadFromUri(MODEL_URL)
    ]);
    
    // Initialize TensorFlow.js
    await tf.ready();
    
    modelsLoaded = true;
    console.log('Face detection models loaded successfully');
  } catch (error) {
    console.error('Error loading face detection models:', error);
    throw new Error('Failed to load face detection models');
  }
};

/**
 * Detect faces and emotions in an image
 * @param {HTMLImageElement|HTMLVideoElement|HTMLCanvasElement} input - The input image or video
 * @returns {Promise<faceapi.WithFaceExpressions<faceapi.WithFaceLandmarks<faceapi.WithFaceDetection<{}>>>[]>} - Detection results
 */
export const detectEmotions = async (input: HTMLImageElement | HTMLVideoElement | HTMLCanvasElement) => {
  if (!modelsLoaded) {
    await loadModels();
  }
  
  try {
    // Detect all faces and get expressions
    const detectionOptions = new faceapi.TinyFaceDetectorOptions({ inputSize: 512, scoreThreshold: 0.5 });
    
    const results = await faceapi
      .detectAllFaces(input, detectionOptions)
      .withFaceLandmarks()
      .withFaceExpressions();
    
    // Save results if we have any faces
    if (results.length > 0) {
      const expressions = results[0].expressions;
      
      // Find primary and secondary emotions
      let primaryEmotion = '';
      let primaryConfidence = 0;
      let secondaryEmotion = '';
      let secondaryConfidence = 0;
      
      Object.entries(expressions).forEach(([emotion, confidence]) => {
        if (confidence > primaryConfidence) {
          secondaryEmotion = primaryEmotion;
          secondaryConfidence = primaryConfidence;
          primaryEmotion = emotion;
          primaryConfidence = confidence;
        } else if (confidence > secondaryConfidence) {
          secondaryEmotion = emotion;
          secondaryConfidence = confidence;
        }
      });
      
      // Save to history
      saveEmotionResult({
        timestamp: new Date().toISOString(),
        primaryEmotion,
        primaryConfidence,
        secondaryEmotion,
        secondaryConfidence,
        allEmotions: expressions
      });
    }
    
    return results;
  } catch (error) {
    console.error('Error detecting emotions:', error);
    throw new Error('Failed to detect emotions');
  }
};

/**
 * Draw face detection results on a canvas
 * @param {HTMLCanvasElement} canvas - The canvas element to draw on
 * @param {any[]} detections - Face detection results
 */
export const drawDetections = (canvas: HTMLCanvasElement, detections: any[]) => {
  const ctx = canvas.getContext('2d');
  if (!ctx) return;
  
  // Clear the canvas
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  
  // Draw detections
  faceapi.draw.drawDetections(canvas, detections);
  faceapi.draw.drawFaceLandmarks(canvas, detections);
  
  // Draw expressions for each face
  detections.forEach(detection => {
    const { expressions, detection: { box } } = detection;
    
    // Find the emotion with highest confidence
    let topEmotion = '';
    let topConfidence = 0;
    
    Object.entries(expressions).forEach(([emotion, confidence]) => {
      if (confidence > topConfidence) {
        topEmotion = emotion;
        topConfidence = confidence;
      }
    });
    
    // Draw emotion label
    const text = `${topEmotion} (${Math.round(topConfidence * 100)}%)`;
    const textWidth = ctx.measureText(text).width;
    
    ctx.fillStyle = 'rgba(0, 0, 255, 0.5)';
    ctx.fillRect(box.x, box.y - 20, textWidth + 10, 20);
    
    ctx.fillStyle = 'white';
    ctx.font = '16px Arial';
    ctx.fillText(text, box.x + 5, box.y - 5);
  });
};