import React from 'react';
import { Link } from 'react-router-dom';
import { Brain, Camera, BarChart2, Shield } from 'lucide-react';

const Home = () => {
  return (
    <div className="flex flex-col items-center">
      {/* Hero Section */}
      <section className="w-full bg-gradient-to-r from-indigo-600 to-purple-600 text-white py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row items-center">
            <div className="md:w-1/2 mb-10 md:mb-0">
              <h1 className="text-4xl md:text-5xl font-bold mb-6">
                Advanced Facial Emotion Recognition with AI
              </h1>
              <p className="text-xl mb-8">
                Detect and analyze emotions in real-time using our state-of-the-art convolutional neural network.
              </p>
              <div className="flex flex-col sm:flex-row space-y-4 sm:space-y-0 sm:space-x-4">
                <Link
                  to="/detect"
                  className="bg-white text-indigo-600 font-bold py-3 px-6 rounded-lg shadow-md hover:bg-gray-100 transition duration-300 text-center"
                >
                  Try It Now
                </Link>
                <Link
                  to="/about"
                  className="bg-transparent border-2 border-white text-white font-bold py-3 px-6 rounded-lg hover:bg-white hover:text-indigo-600 transition duration-300 text-center"
                >
                  Learn More
                </Link>
              </div>
            </div>
            <div className="md:w-1/2 flex justify-center">
              <img
                src="https://images.unsplash.com/photo-1499996860823-5214fcc65f8f?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=800&q=80"
                alt="Facial emotion recognition"
                className="rounded-lg shadow-xl max-w-full h-auto"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="w-full py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold text-center mb-12 text-gray-800">Key Features</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            <div className="bg-gray-50 p-6 rounded-lg shadow-md hover:shadow-lg transition duration-300">
              <div className="flex justify-center mb-4">
                <Brain className="h-12 w-12 text-indigo-600" />
              </div>
              <h3 className="text-xl font-semibold mb-2 text-center text-gray-800">Advanced CNN Model</h3>
              <p className="text-gray-600 text-center">
                Powered by a state-of-the-art convolutional neural network trained on diverse datasets.
              </p>
            </div>
            <div className="bg-gray-50 p-6 rounded-lg shadow-md hover:shadow-lg transition duration-300">
              <div className="flex justify-center mb-4">
                <Camera className="h-12 w-12 text-indigo-600" />
              </div>
              <h3 className="text-xl font-semibold mb-2 text-center text-gray-800">Real-time Detection</h3>
              <p className="text-gray-600 text-center">
                Analyze emotions in real-time through your webcam with high accuracy and low latency.
              </p>
            </div>
            <div className="bg-gray-50 p-6 rounded-lg shadow-md hover:shadow-lg transition duration-300">
              <div className="flex justify-center mb-4">
                <BarChart2 className="h-12 w-12 text-indigo-600" />
              </div>
              <h3 className="text-xl font-semibold mb-2 text-center text-gray-800">Detailed Analytics</h3>
              <p className="text-gray-600 text-center">
                Track and visualize emotion patterns over time with comprehensive dashboards.
              </p>
            </div>
            <div className="bg-gray-50 p-6 rounded-lg shadow-md hover:shadow-lg transition duration-300">
              <div className="flex justify-center mb-4">
                <Shield className="h-12 w-12 text-indigo-600" />
              </div>
              <h3 className="text-xl font-semibold mb-2 text-center text-gray-800">Privacy Focused</h3>
              <p className="text-gray-600 text-center">
                All processing happens in your browser. Your facial data never leaves your device.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* How It Works Section */}
      <section className="w-full py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold text-center mb-12 text-gray-800">How It Works</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="flex flex-col items-center">
              <div className="bg-indigo-100 rounded-full p-4 mb-4">
                <span className="text-indigo-600 font-bold text-2xl">1</span>
              </div>
              <h3 className="text-xl font-semibold mb-2 text-gray-800">Face Detection</h3>
              <p className="text-gray-600 text-center">
                Our system first detects faces in the image or video stream using advanced face detection algorithms.
              </p>
            </div>
            <div className="flex flex-col items-center">
              <div className="bg-indigo-100 rounded-full p-4 mb-4">
                <span className="text-indigo-600 font-bold text-2xl">2</span>
              </div>
              <h3 className="text-xl font-semibold mb-2 text-gray-800">Feature Extraction</h3>
              <p className="text-gray-600 text-center">
                The CNN model extracts key facial features that are relevant for emotion recognition.
              </p>
            </div>
            <div className="flex flex-col items-center">
              <div className="bg-indigo-100 rounded-full p-4 mb-4">
                <span className="text-indigo-600 font-bold text-2xl">3</span>
              </div>
              <h3 className="text-xl font-semibold mb-2 text-gray-800">Emotion Classification</h3>
              <p className="text-gray-600 text-center">
                The extracted features are classified into seven basic emotions: happy, sad, angry, surprised, fearful, disgusted, and neutral.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="w-full py-16 bg-indigo-600 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl font-bold mb-6">Ready to experience emotion recognition?</h2>
          <p className="text-xl mb-8 max-w-3xl mx-auto">
            Try our real-time emotion detection system now and see the power of AI in action.
          </p>
          <Link
            to="/detect"
            className="bg-white text-indigo-600 font-bold py-3 px-8 rounded-lg shadow-md hover:bg-gray-100 transition duration-300 inline-block"
          >
            Get Started
          </Link>
        </div>
      </section>
    </div>
  );
};

export default Home;