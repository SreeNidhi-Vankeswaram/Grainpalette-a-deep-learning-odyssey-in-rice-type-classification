import React, { useRef, useState, useEffect } from 'react';
import Webcam from 'react-webcam';
import * as faceapi from 'face-api.js';
import { Camera, AlertCircle, RefreshCw, Download } from 'lucide-react';
import { loadModels, detectEmotions } from '../utils/faceDetection';

const emotions = ['angry', 'disgusted', 'fearful', 'happy', 'neutral', 'sad', 'surprised'];
const emotionColors = {
  angry: 'bg-red-500',
  disgusted: 'bg-green-700',
  fearful: 'bg-purple-500',
  happy: 'bg-yellow-500',
  neutral: 'bg-gray-500',
  sad: 'bg-blue-500',
  surprised: 'bg-pink-500'
};

const EmotionDetection = () => {
  const webcamRef = useRef<Webcam>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [isModelLoading, setIsModelLoading] = useState(true);
  const [isDetecting, setIsDetecting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [emotionResults, setEmotionResults] = useState<{[key: string]: number} | null>(null);
  const [capturedImage, setCapturedImage] = useState<string | null>(null);

  useEffect(() => {
    const loadFaceDetectionModels = async () => {
      try {
        setIsModelLoading(true);
        await loadModels();
        setIsModelLoading(false);
      } catch (err) {
        setError('Failed to load face detection models. Please try again later.');
        setIsModelLoading(false);
        console.error('Error loading models:', err);
      }
    };

    loadFaceDetectionModels();
  }, []);

  const handleStartDetection = async () => {
    if (!webcamRef.current || isModelLoading) return;
    
    setIsDetecting(true);
    setError(null);
    
    try {
      const imageSrc = webcamRef.current.getScreenshot();
      if (!imageSrc) {
        throw new Error('Failed to capture image from webcam');
      }
      
      setCapturedImage(imageSrc);
      
      const img = new Image();
      img.src = imageSrc;
      
      img.onload = async () => {
        if (!canvasRef.current) return;
        
        const canvas = canvasRef.current;
        const ctx = canvas.getContext('2d');
        if (!ctx) return;
        
        // Set canvas dimensions to match image
        canvas.width = img.width;
        canvas.height = img.height;
        
        // Draw the image on canvas
        ctx.drawImage(img, 0, 0);
        
        // Detect faces and emotions
        const results = await detectEmotions(img);
        
        if (results.length === 0) {
          setError('No faces detected. Please try again.');
          setIsDetecting(false);
          return;
        }
        
        // Draw face detections on canvas
        faceapi.draw.drawDetections(canvas, results);
        
        // Get emotion results from the first face
        const emotions = results[0].expressions;
        setEmotionResults(emotions);
        
        setIsDetecting(false);
      };
    } catch (err) {
      setError('An error occurred during detection. Please try again.');
      setIsDetecting(false);
      console.error('Detection error:', err);
    }
  };

  const handleReset = () => {
    setCapturedImage(null);
    setEmotionResults(null);
    setError(null);
  };

  const handleDownload = () => {
    if (!canvasRef.current) return;
    
    const link = document.createElement('a');
    link.download = 'emotion-detection.png';
    link.href = canvasRef.current.toDataURL('image/png');
    link.click();
  };

  const getTopEmotion = () => {
    if (!emotionResults) return null;
    
    let topEmotion = '';
    let topScore = 0;
    
    Object.entries(emotionResults).forEach(([emotion, score]) => {
      if (score > topScore) {
        topScore = score;
        topEmotion = emotion;
      }
    });
    
    return { emotion: topEmotion, score: topScore };
  };

  const topEmotion = getTopEmotion();

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <h1 className="text-3xl font-bold text-center mb-8 text-gray-800">Real-time Emotion Detection</h1>
      
      {error && (
        <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-6 flex items-center">
          <AlertCircle className="h-5 w-5 mr-2" />
          <span>{error}</span>
        </div>
      )}
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <div className="bg-white p-6 rounded-lg shadow-md">
          <h2 className="text-xl font-semibold mb-4 text-gray-800">Camera Feed</h2>
          
          <div className="relative">
            {!capturedImage ? (
              <Webcam
                audio={false}
                ref={webcamRef}
                screenshotFormat="image/jpeg"
                className="w-full rounded-lg"
                videoConstraints={{
                  width: 640,
                  height: 480,
                  facingMode: "user"
                }}
              />
            ) : (
              <div className="relative">
                <img src={capturedImage} alt="Captured" className="w-full rounded-lg" />
                <canvas ref={canvasRef} className="absolute top-0 left-0 w-full h-full" />
              </div>
            )}
            
            {isModelLoading && (
              <div className="absolute inset-0 flex items-center justify-center bg-black bg-opacity-50 rounded-lg">
                <div className="text-white text-center">
                  <RefreshCw className="h-10 w-10 mx-auto mb-2 animate-spin" />
                  <p>Loading face detection models...</p>
                </div>
              </div>
            )}
          </div>
          
          <div className="mt-4 flex flex-wrap gap-2">
            {!capturedImage ? (
              <button
                onClick={handleStartDetection}
                disabled={isModelLoading || isDetecting}
                className={`flex items-center px-4 py-2 rounded-md font-medium ${
                  isModelLoading || isDetecting
                    ? 'bg-gray-300 text-gray-500 cursor-not-allowed'
                    : 'bg-indigo-600 text-white hover:bg-indigo-700'
                }`}
              >
                <Camera className="h-5 w-5 mr-2" />
                {isDetecting ? 'Detecting...' : 'Detect Emotions'}
              </button>
            ) : (
              <>
                <button
                  onClick={handleReset}
                  className="flex items-center px-4 py-2 bg-gray-600 text-white rounded-md font-medium hover:bg-gray-700"
                >
                  <RefreshCw className="h-5 w-5 mr-2" />
                  Try Again
                </button>
                
                <button
                  onClick={handleDownload}
                  className="flex items-center px-4 py-2 bg-green-600 text-white rounded-md font-medium hover:bg-green-700"
                >
                  <Download className="h-5 w-5 mr-2" />
                  Download Result
                </button>
              </>
            )}
          </div>
        </div>
        
        <div className="bg-white p-6 rounded-lg shadow-md">
          <h2 className="text-xl font-semibold mb-4 text-gray-800">Emotion Analysis</h2>
          
          {emotionResults ? (
            <div>
              <div className="mb-6 p-4 rounded-lg bg-indigo-50">
                <h3 className="text-lg font-medium mb-2 text-gray-800">Primary Emotion</h3>
                <div className="flex items-center">
                  <div className={`w-16 h-16 rounded-full flex items-center justify-center text-white text-2xl font-bold ${emotionColors[topEmotion?.emotion as keyof typeof emotionColors] || 'bg-gray-400'}`}>
                    {topEmotion?.score ? Math.round(topEmotion.score * 100) : 0}%
                  </div>
                  <div className="ml-4">
                    <p className="text-2xl font-bold capitalize text-gray-800">{topEmotion?.emotion || 'Unknown'}</p>
                    <p className="text-gray-600">Confidence level: {topEmotion?.score ? (topEmotion.score * 100).toFixed(2) : 0}%</p>
                  </div>
                </div>
              </div>
              
              <h3 className="text-lg font-medium mb-3 text-gray-800">All Emotions</h3>
              <div className="space-y-3">
                {emotions.map(emotion => (
                  <div key={emotion} className="relative pt-1">
                    <div className="flex items-center justify-between mb-1">
                      <div className="capitalize font-medium text-gray-700">{emotion}</div>
                      <div className="text-gray-600 text-sm">
                        {emotionResults[emotion] ? (emotionResults[emotion] * 100).toFixed(2) : 0}%
                      </div>
                    </div>
                    <div className="overflow-hidden h-2 text-xs flex rounded bg-gray-200">
                      <div
                        style={{ width: `${emotionResults[emotion] ? emotionResults[emotion] * 100 : 0}%` }}
                        className={`shadow-none flex flex-col text-center whitespace-nowrap text-white justify-center ${emotionColors[emotion as keyof typeof emotionColors]}`}
                      ></div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ) : (
            <div className="flex flex-col items-center justify-center h-64 text-gray-500">
              <Camera className="h-12 w-12 mb-4" />
              <p className="text-center">
                Capture an image to analyze emotions. Make sure your face is clearly visible and well-lit.
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default EmotionDetection;