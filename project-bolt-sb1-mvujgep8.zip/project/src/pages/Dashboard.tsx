import React, { useState, useEffect } from 'react';
import { BarChart2, PieChart, Calendar, Clock, Download } from 'lucide-react';
import { getEmotionHistory } from '../utils/emotionStorage';

const Dashboard = () => {
  const [timeRange, setTimeRange] = useState('week');
  const [emotionData, setEmotionData] = useState<any[]>([]);
  
  useEffect(() => {
    // Load emotion history data
    const history = getEmotionHistory();
    setEmotionData(history);
  }, []);

  // Calculate emotion statistics
  const calculateStats = () => {
    if (emotionData.length === 0) return null;
    
    const totalEntries = emotionData.length;
    const emotionCounts: {[key: string]: number} = {
      happy: 0,
      sad: 0,
      angry: 0,
      surprised: 0,
      fearful: 0,
      disgusted: 0,
      neutral: 0
    };
    
    // Count occurrences of each emotion
    emotionData.forEach(entry => {
      emotionCounts[entry.primaryEmotion] = (emotionCounts[entry.primaryEmotion] || 0) + 1;
    });
    
    // Calculate percentages
    const emotionPercentages = Object.entries(emotionCounts).map(([emotion, count]) => ({
      emotion,
      percentage: (count / totalEntries) * 100
    }));
    
    // Sort by percentage (descending)
    emotionPercentages.sort((a, b) => b.percentage - a.percentage);
    
    return {
      totalEntries,
      emotionCounts,
      emotionPercentages
    };
  };

  const stats = calculateStats();
  
  // Mock data for charts
  const mockWeeklyData = [
    { day: 'Mon', happy: 65, sad: 10, angry: 5, neutral: 20 },
    { day: 'Tue', happy: 45, sad: 15, angry: 10, neutral: 30 },
    { day: 'Wed', happy: 30, sad: 30, angry: 15, neutral: 25 },
    { day: 'Thu', happy: 55, sad: 20, angry: 5, neutral: 20 },
    { day: 'Fri', happy: 70, sad: 10, angry: 5, neutral: 15 },
    { day: 'Sat', happy: 80, sad: 5, angry: 5, neutral: 10 },
    { day: 'Sun', happy: 75, sad: 10, angry: 5, neutral: 10 }
  ];

  const emotionColors = {
    happy: '#EAB308', // yellow-500
    sad: '#3B82F6',   // blue-500
    angry: '#EF4444', // red-500
    surprised: '#EC4899', // pink-500
    fearful: '#8B5CF6', // purple-500
    disgusted: '#10B981', // green-500
    neutral: '#6B7280'  // gray-500
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-8">
        <h1 className="text-3xl font-bold text-gray-800 mb-4 md:mb-0">Emotion Analytics Dashboard</h1>
        
        <div className="flex space-x-2">
          <button
            onClick={() => setTimeRange('week')}
            className={`px-4 py-2 rounded-md ${
              timeRange === 'week' ? 'bg-indigo-600 text-white' : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
            }`}
          >
            Week
          </button>
          <button
            onClick={() => setTimeRange('month')}
            className={`px-4 py-2 rounded-md ${
              timeRange === 'month' ? 'bg-indigo-600 text-white' : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
            }`}
          >
            Month
          </button>
          <button
            onClick={() => setTimeRange('year')}
            className={`px-4 py-2 rounded-md ${
              timeRange === 'year' ? 'bg-indigo-600 text-white' : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
            }`}
          >
            Year
          </button>
        </div>
      </div>
      
      {stats ? (
        <>
          {/* Stats Cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            <div className="bg-white rounded-lg shadow-md p-6">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-medium text-gray-700">Total Sessions</h3>
                <Calendar className="h-6 w-6 text-indigo-600" />
              </div>
              <p className="text-3xl font-bold text-gray-800">{stats.totalEntries}</p>
              <p className="text-sm text-gray-500 mt-2">Emotion detection sessions</p>
            </div>
            
            <div className="bg-white rounded-lg shadow-md p-6">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-medium text-gray-700">Primary Emotion</h3>
                <PieChart className="h-6 w-6 text-indigo-600" />
              </div>
              <p className="text-3xl font-bold text-gray-800 capitalize">
                {stats.emotionPercentages[0]?.emotion || 'N/A'}
              </p>
              <p className="text-sm text-gray-500 mt-2">
                {stats.emotionPercentages[0]?.percentage.toFixed(1) || 0}% of all emotions
              </p>
            </div>
            
            <div className="bg-white rounded-lg shadow-md p-6">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-medium text-gray-700">Last Session</h3>
                <Clock className="h-6 w-6 text-indigo-600" />
              </div>
              <p className="text-3xl font-bold text-gray-800">
                {emotionData.length > 0 ? new Date(emotionData[emotionData.length - 1].timestamp).toLocaleDateString() : 'N/A'}
              </p>
              <p className="text-sm text-gray-500 mt-2">
                {emotionData.length > 0 ? new Date(emotionData[emotionData.length - 1].timestamp).toLocaleTimeString() : 'No sessions yet'}
              </p>
            </div>
            
            <div className="bg-white rounded-lg shadow-md p-6">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-medium text-gray-700">Emotion Variety</h3>
                <BarChart2 className="h-6 w-6 text-indigo-600" />
              </div>
              <p className="text-3xl font-bold text-gray-800">
                {Object.values(stats.emotionCounts).filter(count => count > 0).length}
              </p>
              <p className="text-sm text-gray-500 mt-2">
                Different emotions detected
              </p>
            </div>
          </div>
          
          {/* Charts */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
            <div className="bg-white rounded-lg shadow-md p-6">
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-lg font-medium text-gray-800">Emotion Distribution</h3>
                <button className="text-indigo-600 hover:text-indigo-800 flex items-center text-sm">
                  <Download className="h-4 w-4 mr-1" />
                  Export
                </button>
              </div>
              
              <div className="h-64 flex items-center justify-center">
                <div className="w-full max-w-xs">
                  {stats.emotionPercentages.map(({ emotion, percentage }) => (
                    <div key={emotion} className="mb-4">
                      <div className="flex items-center justify-between mb-1">
                        <span className="text-sm font-medium text-gray-700 capitalize">{emotion}</span>
                        <span className="text-sm text-gray-500">{percentage.toFixed(1)}%</span>
                      </div>
                      <div className="w-full bg-gray-200 rounded-full h-2.5">
                        <div 
                          className="h-2.5 rounded-full" 
                          style={{ 
                            width: `${percentage}%`,
                            backgroundColor: emotionColors[emotion as keyof typeof emotionColors] || '#6B7280'
                          }}
                        ></div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
            
            <div className="bg-white rounded-lg shadow-md p-6">
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-lg font-medium text-gray-800">Weekly Trend</h3>
                <button className="text-indigo-600 hover:text-indigo-800 flex items-center text-sm">
                  <Download className="h-4 w-4 mr-1" />
                  Export
                </button>
              </div>
              
              <div className="h-64 flex items-center justify-center">
                {/* This would be a chart in a real implementation */}
                <div className="w-full flex items-end justify-between h-48 border-b border-l border-gray-200 relative">
                  {mockWeeklyData.map((day, index) => (
                    <div key={index} className="flex flex-col items-center" style={{ width: `${100 / mockWeeklyData.length}%` }}>
                      <div className="w-full flex items-end justify-center space-x-0.5 h-40">
                        <div 
                          className="w-2 bg-yellow-500" 
                          style={{ height: `${day.happy * 0.4}%` }}
                          title={`Happy: ${day.happy}%`}
                        ></div>
                        <div 
                          className="w-2 bg-blue-500" 
                          style={{ height: `${day.sad * 0.4}%` }}
                          title={`Sad: ${day.sad}%`}
                        ></div>
                        <div 
                          className="w-2 bg-red-500" 
                          style={{ height: `${day.angry * 0.4}%` }}
                          title={`Angry: ${day.angry}%`}
                        ></div>
                        <div 
                          className="w-2 bg-gray-500" 
                          style={{ height: `${day.neutral * 0.4}%` }}
                          title={`Neutral: ${day.neutral}%`}
                        ></div>
                      </div>
                      <span className="text-xs text-gray-500 mt-2">{day.day}</span>
                    </div>
                  ))}
                  
                  {/* Y-axis labels */}
                  <div className="absolute -left-6 top-0 h-full flex flex-col justify-between text-xs text-gray-500">
                    <span>100%</span>
                    <span>75%</span>
                    <span>50%</span>
                    <span>25%</span>
                    <span>0%</span>
                  </div>
                </div>
              </div>
              
              <div className="flex justify-center mt-4">
                <div className="flex items-center space-x-4 text-sm">
                  <div className="flex items-center">
                    <div className="w-3 h-3 bg-yellow-500 mr-1"></div>
                    <span>Happy</span>
                  </div>
                  <div className="flex items-center">
                    <div className="w-3 h-3 bg-blue-500 mr-1"></div>
                    <span>Sad</span>
                  </div>
                  <div className="flex items-center">
                    <div className="w-3 h-3 bg-red-500 mr-1"></div>
                    <span>Angry</span>
                  </div>
                  <div className="flex items-center">
                    <div className="w-3 h-3 bg-gray-500 mr-1"></div>
                    <span>Neutral</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
          
          {/* Recent Sessions */}
          <div className="bg-white rounded-lg shadow-md p-6">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-lg font-medium text-gray-800">Recent Sessions</h3>
              <button className="text-indigo-600 hover:text-indigo-800 flex items-center text-sm">
                <Download className="h-4 w-4 mr-1" />
                Export All
              </button>
            </div>
            
            {emotionData.length > 0 ? (
              <div className="overflow-x-auto">
                <table className="min-w-full divide-y divide-gray-200">
                  <thead className="bg-gray-50">
                    <tr>
                      <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Date & Time
                      </th>
                      <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Primary Emotion
                      </th>
                      <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Confidence
                      </th>
                      <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Secondary Emotion
                      </th>
                    </tr>
                  </thead>
                  <tbody className="bg-white divide-y divide-gray-200">
                    {emotionData.slice(-5).reverse().map((entry, index) => (
                      <tr key={index}>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                          {new Date(entry.timestamp).toLocaleString()}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="flex items-center">
                            <div 
                              className="w-3 h-3 rounded-full mr-2"
                              style={{ backgroundColor: emotionColors[entry.primaryEmotion as keyof typeof emotionColors] || '#6B7280' }}
                            ></div>
                            <span className="text-sm font-medium text-gray-900 capitalize">{entry.primaryEmotion}</span>
                          </div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                          {(entry.primaryConfidence * 100).toFixed(1)}%
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="flex items-center">
                            <div 
                              className="w-3 h-3 rounded-full mr-2"
                              style={{ backgroundColor: emotionColors[entry.secondaryEmotion as keyof typeof emotionColors] || '#6B7280' }}
                            ></div>
                            <span className="text-sm font-medium text-gray-900 capitalize">{entry.secondaryEmotion}</span>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            ) : (
              <div className="text-center py-12 text-gray-500">
                <p>No emotion detection sessions recorded yet.</p>
                <p className="mt-2">Try the emotion detection feature to start collecting data.</p>
              </div>
            )}
          </div>
        </>
      ) : (
        <div className="bg-white rounded-lg shadow-md p-8 text-center">
          <BarChart2 className="h-16 w-16 text-gray-400 mx-auto mb-4" />
          <h2 className="text-2xl font-bold text-gray-700 mb-2">No Data Available</h2>
          <p className="text-gray-500 mb-6">
            You haven't recorded any emotion detection sessions yet. Use the emotion detection feature to start collecting data.
          </p>
          <a
            href="/detect"
            className="inline-flex items-center px-4 py-2 bg-indigo-600 text-white rounded-md hover:bg-indigo-700"
          >
            <Camera className="h-5 w-5 mr-2" />
            Try Emotion Detection
          </a>
        </div>
      )}
    </div>
  );
};

export default Dashboard;