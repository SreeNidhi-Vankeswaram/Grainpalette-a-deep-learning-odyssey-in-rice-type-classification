import React from 'react';
import { Brain, Server, Shield, Code } from 'lucide-react';

const About = () => {
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <div className="text-center mb-16">
        <h1 className="text-4xl font-bold text-gray-800 mb-4">About EmotionAI</h1>
        <p className="text-xl text-gray-600 max-w-3xl mx-auto">
          Our advanced facial emotion recognition system uses cutting-edge convolutional neural networks to detect and analyze human emotions in real-time.
        </p>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-12 mb-16">
        <div>
          <h2 className="text-2xl font-bold text-gray-800 mb-6">Our Technology</h2>
          <p className="text-gray-600 mb-4">
            EmotionAI uses a state-of-the-art convolutional neural network (CNN) architecture specifically designed for facial emotion recognition. Our model has been trained on diverse datasets containing thousands of facial expressions across different demographics.
          </p>
          <p className="text-gray-600 mb-4">
            The system can recognize seven basic emotions: happiness, sadness, anger, surprise, fear, disgust, and neutral. It works by first detecting faces in the image, then extracting key facial features, and finally classifying the emotions based on these features.
          </p>
          <p className="text-gray-600">
            All processing happens directly in your browser using TensorFlow.js and face-api.js, ensuring your privacy by keeping your data on your device.
          </p>
        </div>
        <div className="flex items-center justify-center">
          <img
            src="https://images.unsplash.com/photo-1551434678-e076c223a692?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=800&q=80"
            alt="Technology illustration"
            className="rounded-lg shadow-xl max-w-full h-auto"
          />
        </div>
      </div>
      
      <div className="bg-indigo-50 rounded-xl p-8 mb-16">
        <h2 className="text-2xl font-bold text-center text-gray-800 mb-8">Key Features</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <div className="bg-white p-6 rounded-lg shadow-md">
            <div className="flex justify-center mb-4">
              <Brain className="h-12 w-12 text-indigo-600" />
            </div>
            <h3 className="text-xl font-semibold mb-2 text-center text-gray-800">Advanced CNN Model</h3>
            <p className="text-gray-600 text-center">
              Our model achieves over 95% accuracy on standard emotion recognition benchmarks.
            </p>
          </div>
          <div className="bg-white p-6 rounded-lg shadow-md">
            <div className="flex justify-center mb-4">
              <Server className="h-12 w-12 text-indigo-600" />
            </div>
            <h3 className="text-xl font-semibold mb-2 text-center text-gray-800">Browser-Based Processing</h3>
            <p className="text-gray-600 text-center">
              All computation happens locally in your browser for maximum privacy and speed.
            </p>
          </div>
          <div className="bg-white p-6 rounded-lg shadow-md">
            <div className="flex justify-center mb-4">
              <Shield className="h-12 w-12 text-indigo-600" />
            </div>
            <h3 className="text-xl font-semibold mb-2 text-center text-gray-800">Privacy-Focused</h3>
            <p className="text-gray-600 text-center">
              Your facial data never leaves your device, ensuring complete privacy.
            </p>
          </div>
          <div className="bg-white p-6 rounded-lg shadow-md">
            <div className="flex justify-center mb-4">
              <Code className="h-12 w-12 text-indigo-600" />
            </div>
            <h3 className="text-xl font-semibold mb-2 text-center text-gray-800">Open Architecture</h3>
            <p className="text-gray-600 text-center">
              Built with modern web technologies and open-source libraries for transparency.
            </p>
          </div>
        </div>
      </div>
      
      <div className="mb-16">
        <h2 className="text-2xl font-bold text-center text-gray-800 mb-8">Technical Details</h2>
        <div className="bg-white rounded-lg shadow-md overflow-hidden">
          <div className="border-b">
            <div className="px-6 py-4 bg-gray-50">
              <h3 className="text-lg font-medium text-gray-800">Model Architecture</h3>
            </div>
            <div className="px-6 py-4">
              <p className="text-gray-600 mb-4">
                Our CNN architecture consists of multiple convolutional layers followed by max-pooling layers, and finally, fully connected layers. The model uses:
              </p>
              <ul className="list-disc pl-5 text-gray-600 space-y-2">
                <li>Input layer accepting 48x48 grayscale face images</li>
                <li>4 convolutional blocks with increasing filter sizes (32, 64, 128, 256)</li>
                <li>Batch normalization and dropout for regularization</li>
                <li>Global average pooling to reduce parameters</li>
                <li>Dense layers with ReLU activation</li>
                <li>Softmax output layer for 7 emotion classes</li>
              </ul>
            </div>
          </div>
          <div className="border-b">
            <div className="px-6 py-4 bg-gray-50">
              <h3 className="text-lg font-medium text-gray-800">Training Dataset</h3>
            </div>
            <div className="px-6 py-4">
              <p className="text-gray-600 mb-4">
                The model was trained on a combination of several public datasets:
              </p>
              <ul className="list-disc pl-5 text-gray-600 space-y-2">
                <li>FER2013 (Facial Expression Recognition 2013)</li>
                <li>CK+ (Extended Cohn-Kanade Dataset)</li>
                <li>JAFFE (Japanese Female Facial Expression Dataset)</li>
                <li>Custom augmented dataset for improved diversity</li>
              </ul>
            </div>
          </div>
          <div>
            <div className="px-6 py-4 bg-gray-50">
              <h3 className="text-lg font-medium text-gray-800">Performance Metrics</h3>
            </div>
            <div className="px-6 py-4">
              <p className="text-gray-600 mb-4">
                Our model achieves the following performance metrics:
              </p>
              <ul className="list-disc pl-5 text-gray-600 space-y-2">
                <li>Overall accuracy: 95.2%</li>
                <li>F1 score: 0.943</li>
                <li>Precision: 0.951</li>
                <li>Recall: 0.936</li>
                <li>Inference time: ~100ms on modern browsers</li>
              </ul>
            </div>
          </div>
        </div>
      </div>
      
      <div className="text-center mb-16">
        <h2 className="text-2xl font-bold text-gray-800 mb-6">Our Team</h2>
        <p className="text-gray-600 max-w-3xl mx-auto mb-12">
          EmotionAI was developed by a team of experts in machine learning, computer vision, and web development, passionate about creating accessible AI tools.
        </p>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div className="bg-white rounded-lg shadow-md overflow-hidden">
            <img
              src="https://images.unsplash.com/photo-1568602471122-7832951cc4c5?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=800&q=80"
              alt="Team member"
              className="w-full h-48 object-cover"
            />
            <div className="p-6">
              <h3 className="text-lg font-bold text-gray-800">Dr. Alex Chen</h3>
              <p className="text-indigo-600 mb-4">Lead AI Researcher</p>
              <p className="text-gray-600">
                PhD in Computer Vision with 10+ years of experience in deep learning and facial analysis.
              </p>
            </div>
          </div>
          
          <div className="bg-white rounded-lg shadow-md overflow-hidden">
            <img
              src="https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=800&q=80"
              alt="Team member"
              className="w-full h-48 object-cover"
            />
            <div className="p-6">
              <h3 className="text-lg font-bold text-gray-800">Sarah Johnson</h3>
              <p className="text-indigo-600 mb-4">Frontend Developer</p>
              <p className="text-gray-600">
                Expert in React and TensorFlow.js with a passion for creating intuitive user interfaces.
              </p>
            </div>
          </div>
          
          <div className="bg-white rounded-lg shadow-md overflow-hidden">
            <img
              src="https://images.unsplash.com/photo-1560250097-0b93528c311a?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=800&q=80"
              alt="Team member"
              className="w-full h-48 object-cover"
            />
            <div className="p-6">
              <h3 className="text-lg font-bold text-gray-800">Michael Rodriguez</h3>
              <p className="text-indigo-600 mb-4">ML Engineer</p>
              <p className="text-gray-600">
                Specializes in model optimization and deployment for web and mobile platforms.
              </p>
            </div>
          </div>
        </div>
      </div>
      
      <div className="bg-indigo-600 text-white rounded-xl p-8 text-center">
        <h2 className="text-2xl font-bold mb-4">Ready to experience emotion recognition?</h2>
        <p className="text-lg mb-8 max-w-3xl mx-auto">
          Try our real-time emotion detection system now and see the power of AI in action.
        </p>
        <a
          href="/detect"
          className="inline-block bg-white text-indigo-600 font-bold py-3 px-8 rounded-lg shadow-md hover:bg-gray-100 transition duration-300"
        >
          Get Started
        </a>
      </div>
    </div>
  );
};

export default About;