import React from 'react';
import { Link } from 'react-router-dom';

const Home = () => {
  return (
    <div className="bg-gradient-to-b from-blue-50 to-white">
      {/* Hero Section */}
      <section className="py-20 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
        <div className="text-center">
          <h1 className="text-4xl md:text-5xl font-bold mb-6">
            <span className="gradient-text">GrainPalette</span>
          </h1>
          <p className="text-xl md:text-2xl text-gray-700 mb-8">
            A Deep Learning Odyssey in Rice Type Classification
          </p>
          <div className="flex flex-col sm:flex-row justify-center gap-4">
            <Link to="/classify" className="btn-primary">
              Classify Rice
            </Link>
            <Link to="/dataset" className="btn-secondary">
              Explore Dataset
            </Link>
          </div>
        </div>
        
        <div className="mt-16 bg-white rounded-xl shadow-lg p-6 md:p-8">
          <img 
            src="https://images.unsplash.com/photo-1586201375761-83865001e8ac?ixlib=rb-1.2.1&auto=format&fit=crop&w=1200&q=80" 
            alt="Various types of rice grains" 
            className="w-full h-64 md:h-96 object-cover rounded-lg mb-8"
          />
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="text-center">
              <div className="bg-blue-100 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-blue-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m2.828 9.9a5 5 0 117.072 0l-.548.547A3.374 3.374 0 0014 18.469V19a2 2 0 11-4 0v-.531c0-.895-.356-1.754-.988-2.386l-.548-.547z" />
                </svg>
              </div>
              <h3 className="text-xl font-semibold mb-2">Deep Learning</h3>
              <p className="text-gray-600">
                Utilizing convolutional neural networks to accurately classify rice varieties based on visual characteristics.
              </p>
            </div>
            
            <div className="text-center">
              <div className="bg-green-100 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-green-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2" />
                </svg>
              </div>
              <h3 className="text-xl font-semibold mb-2">Comprehensive Dataset</h3>
              <p className="text-gray-600">
                Trained on thousands of rice grain images across multiple varieties, ensuring high classification accuracy.
              </p>
            </div>
            
            <div className="text-center">
              <div className="bg-purple-100 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-purple-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M11 3.055A9.001 9.001 0 1020.945 13H11V3.055z" />
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M20.488 9H15V3.512A9.025 9.025 0 0120.488 9z" />
                </svg>
              </div>
              <h3 className="text-xl font-semibold mb-2">Real-time Analysis</h3>
              <p className="text-gray-600">
                Instant classification results with detailed confidence scores and visual explanations.
              </p>
            </div>
          </div>
        </div>
      </section>
      
      {/* Rice Varieties Section */}
      <section className="py-16 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
        <h2 className="text-3xl font-bold text-center mb-12">Rice Varieties We Classify</h2>
        
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
          {[
            { name: 'Basmati', description: 'Long-grain aromatic rice with a nutty flavor', image: 'https://images.unsplash.com/photo-1516824711718-9c1e683412ac?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80' },
            { name: 'Jasmine', description: 'Fragrant long-grain rice with a subtle floral aroma', image: 'https://images.unsplash.com/photo-1536304993881-ff6e9eefa2a6?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80' },
            { name: 'Arborio', description: 'Short-grain rice with high starch content, ideal for risotto', image: 'https://images.unsplash.com/photo-1612257999756-61d09a688ef1?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80' },
            { name: 'Brown Rice', description: 'Whole grain rice with the bran layer intact', image: 'https://images.unsplash.com/photo-1595489226792-47149c17cbf1?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80' },
            { name: 'Wild Rice', description: 'Not true rice, but seeds of aquatic grasses', image: 'https://images.unsplash.com/photo-1590165482129-1b8b27698780?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80' },
            { name: 'Sushi Rice', description: 'Short-grain Japanese rice with sticky texture', image: 'https://images.unsplash.com/photo-1579027989536-b7b1f875659b?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80' }
          ].map((variety, index) => (
            <div key={index} className="card hover:scale-105">
              <img 
                src={variety.image} 
                alt={variety.name} 
                className="w-full h-48 object-cover"
              />
              <div className="p-6">
                <h3 className="text-xl font-semibold mb-2">{variety.name}</h3>
                <p className="text-gray-600">{variety.description}</p>
              </div>
            </div>
          ))}
        </div>
      </section>
      
      {/* CTA Section */}
      <section className="py-16 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
        <div className="bg-gradient-to-r from-blue-500 to-purple-600 rounded-xl shadow-xl p-8 md:p-12 text-white text-center">
          <h2 className="text-3xl font-bold mb-4">Ready to Classify Rice?</h2>
          <p className="text-xl mb-8 max-w-3xl mx-auto">
            Upload your rice grain images and let our deep learning model identify the variety with high accuracy.
          </p>
          <Link to="/classify" className="inline-block bg-white text-blue-600 font-medium py-3 px-8 rounded-lg hover:bg-gray-100 transition-colors duration-300">
            Start Classifying
          </Link>
        </div>
      </section>
    </div>
  );
};

export default Home;