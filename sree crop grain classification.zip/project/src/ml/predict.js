import * as tf from '@tensorflow/tfjs-node';
import { loadModel } from './model';

/**
 * Main prediction script for command-line usage
 */
async function main() {
  console.log('Rice Classification Prediction Tool');
  console.log('----------------------------------');
  
  try {
    // Check if image path was provided
    const imagePath = process.argv[2];
    if (!imagePath) {
      console.error('Please provide an image path: node predict.js <image_path>');
      process.exit(1);
    }
    
    console.log(`Loading model...`);
    const model = await loadModel();
    
    console.log(`Processing image: ${imagePath}`);
    console.log('In a real application, this would:');
    console.log('1. Load the image from the provided path');
    console.log('2. Preprocess the image for the model');
    console.log('3. Run inference using the loaded model');
    console.log('4. Display the classification results');
    
    // Simulate classification results
    const riceVarieties = [
      'Arborio', 
      'Basmati', 
      'Jasmine', 
      'Brown Rice', 
      'Wild Rice', 
      'Sushi Rice'
    ];
    
    // Generate random predictions for demonstration
    const predictions = riceVarieties.map(variety => ({
      className: variety,
      confidence: Math.random()
    })).sort((a, b) => b.confidence - a.confidence);
    
    // Normalize confidences to sum to 1
    const sum = predictions.reduce((acc, pred) => acc + pred.confidence, 0);
    predictions.forEach(pred => pred.confidence = pred.confidence / sum);
    
    console.log('\nClassification Results:');
    console.log('----------------------');
    predictions.forEach((pred, index) => {
      console.log(`${index + 1}. ${pred.className}: ${(pred.confidence * 100).toFixed(2)}%`);
    });
    
    console.log('\nTop prediction:', predictions[0].className);
    
  } catch (error) {
    console.error('Error during prediction:', error);
  }
}

// Run the prediction script
main().then(() => console.log('\nPrediction completed'));